//
//  NPRCodeSampleApp.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/27/25.
//

import SwiftUI

@main
struct NPRCodeSampleApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
