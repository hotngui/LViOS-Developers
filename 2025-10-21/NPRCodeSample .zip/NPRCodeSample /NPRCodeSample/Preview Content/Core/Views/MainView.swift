//
//  MainView.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/30/25.
//

import SwiftUI

struct MainView: View {
    @StateObject private var audioPlayer = AudioPlayerViewModel()
    @StateObject private var podcastViewModel = PodcastFeedViewModel()
    
    var body: some View {
        VStack(spacing: 0) {
            
            NavigationStack {
                PodcastEpisodeListView(
                    podcastShow: PodcastShow.list.first!,
                    viewModel: podcastViewModel
                )
                .navigationTitle("Up First")
            }
            .environmentObject(audioPlayer)
            .overlay(alignment: .bottom) {
                MiniPlayerView()
            }
        }
        .environmentObject(audioPlayer)
        .alert(item: $audioPlayer.audioError) { error in
            Alert(
                title: Text(error.alertTitle),
                message: Text(error.alertMessage),
                dismissButton: .default(Text("OK"))
            )
        }
    }
}

