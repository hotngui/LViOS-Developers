//
//  AudioPlayerError.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/30/25.
//

enum AudioPlayerError: Error, Identifiable {
    case failedToLoadItem
    case sessionSetupFailed(Error)
    
    var id: String {
        switch self {
        case .failedToLoadItem:
            return "failedToLoadItem"
        case .sessionSetupFailed:
            return "sessionSetupFailed"
        }
    }
    
    var alertTitle: String {
        switch self {
        case .failedToLoadItem:
            return "Playback Error"
        case .sessionSetupFailed:
            return "Audio System Error"
        }
    }
    
    var alertMessage: String {
        switch self {
        case .failedToLoadItem:
            return "The selected audio could not be played. Please check the network connection or try a different episode."
        case .sessionSetupFailed:
            return "The app could not set up the audio session."
        }
    }
}
