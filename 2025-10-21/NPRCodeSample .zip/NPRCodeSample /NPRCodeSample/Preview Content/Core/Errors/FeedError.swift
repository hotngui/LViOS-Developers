//
//  FeedError.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/30/25.
//

enum FeedError: Error {
    case networkError(Error)
    case parsingError(Error)
    case unknown
    
    var errorDescription: String {
        switch self {
        case .networkError:
            return "A network error occurred. Please check your internet connection and try again."
        case .parsingError:
            return "There was a problem parsing the feed. Please try again later."
        case .unknown:
            return "An unknown error occurred. Please try again."
        }
    }
}
