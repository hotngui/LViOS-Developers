//
//  String+Extensions.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/30/25.
//

extension String {
    //several article teasers or podcast descriptions have weird html symbols and this helps with that.
    /// Removes any HTML tags from a string to return plain text.
    func strippingHTML() -> String {
        return self.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
    }
}
