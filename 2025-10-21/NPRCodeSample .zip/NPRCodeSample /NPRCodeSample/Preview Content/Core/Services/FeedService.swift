//
//  FeedService.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/27/25.
//

import Foundation
import FeedKit

protocol FeedProvidable {
    func fetchPodcastEpisodes(from url: URL) async throws -> [PodcastEpisode]
}

struct FeedProvider: FeedProvidable {
    
    func fetchPodcastEpisodes(from url: URL) async throws -> [PodcastEpisode] {
        do {
            let feed = try await Feed(remoteURL: url)
            switch feed {
            case let .rss(rssFeed):
                return rssFeed.channel?.items?.compactMap { item in
                    guard let title = item.title,
                          let enclosure = item.enclosure,
                          let urlString = enclosure.attributes?.url,
                          let audioURL = URL(string: urlString) else {
                        return nil
                    }
                    return PodcastEpisode(title: title, audioURL: audioURL)
                } ?? []
            case .atom, .json:
                return []
            }
        } catch let error as FeedError {
            throw FeedError.parsingError(error)
        } catch {
            throw FeedError.networkError(error)
        }
    }
}

