//
//  PodcastShow.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/29/25.
//
import Foundation

struct PodcastShow: Identifiable {
    let id = UUID()
    let title: String
    let iconName: String
    let description: String
    let rssURL: URL
}

extension PodcastShow {
    
    static var list: [PodcastShow] = [
        PodcastShow(
            title: "Up First",
            iconName: "upfirst",
            description: "NPR's Up First is the news you need to start your day. The three biggest stories of the day, with reporting and analysis from NPR News — in 10 minutes.",
            rssURL: URL(string: "https://feeds.npr.org/510318/podcast.xml")!
        )
    ]
}
