//
//  PodcastEpisode.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/27/25.
//

import Foundation

struct PodcastEpisode: Identifiable, Equatable {
    let id = UUID()
    let title: String
    let audioURL: URL
}
