//
//  PodcastListView.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/27/25.
//

import SwiftUI
import AVFoundation

struct PodcastEpisodeListView: View {
    let podcastShow: PodcastShow
    @ObservedObject var viewModel: PodcastFeedViewModel
    @EnvironmentObject var audioPlayer: AudioPlayerViewModel

    var body: some View {
        Group {
            if viewModel.isLoading {
                ProgressView("Loading Episodes...")
            } else if let error = viewModel.errorMessage {
                VStack {
                    Text(error.errorDescription).foregroundColor(.red)
                    //retry button if fail to load
                    Button("Retry") { Task { await viewModel.fetchEpisodes(from: podcastShow.rssURL) } }
                }
            } else {
                List(viewModel.episodes) { episode in
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(episode.title).font(.headline)
                            
                            Text(podcastShow.title).font(.subheadline).foregroundColor(.secondary)
                        }
                        Spacer()
                        PlayButton(show: podcastShow, episode: episode)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        audioPlayer.play(show: podcastShow, episode: episode)
                    }
                }
                .listStyle(.plain)
            }
        }
        .navigationTitle(podcastShow.title)
        .task {
            await viewModel.fetchEpisodes(from: podcastShow.rssURL)
        }
    }
}
