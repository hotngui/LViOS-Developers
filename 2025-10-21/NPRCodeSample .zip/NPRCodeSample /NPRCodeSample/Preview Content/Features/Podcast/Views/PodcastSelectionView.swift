//
//  PodcastSelectionView.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/29/25.
//
import SwiftUI

struct PodcastSelectionView: View {
    @ObservedObject var viewModel: PodcastFeedViewModel
    
    private let shows = PodcastShow.list
    private let gridColumns: [GridItem] = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                LazyVGrid(columns: gridColumns, spacing: 16) {
                    ForEach(shows) { show in
                        NavigationLink(destination: PodcastEpisodeListView(podcastShow: show, viewModel: viewModel)) {
                            VStack {
                                Image(show.iconName)
                                    .resizable()
                                    .scaledToFill()
                                    .font(.system(size: 50))
                                    .foregroundColor(.primary)
                                    .frame(height: 80)
                                    .scaledToFit()
                                    
                                Text(show.title)
                                    .font(.headline)
                                    .foregroundColor(.primary)
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(12)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding()
            }
            .navigationTitle("NPR Podcasts")
        }
    }
}
