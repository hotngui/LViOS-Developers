//
//  MiniPlayerView.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/29/25.
//
import SwiftUI

struct PlayButton: View {
    let show: PodcastShow
    let episode: PodcastEpisode
    @EnvironmentObject var audioPlayer: AudioPlayerViewModel
    
    var body: some View {
        //check if this specific episode is the one currently buffering.
        if audioPlayer.isBuffering && audioPlayer.currentlyPlaying == episode {
            ProgressView()
                .frame(width: 36, height: 36)
        } else {
            let isCurrentlyPlaying = (audioPlayer.currentlyPlaying == episode && audioPlayer.isPlaying)
            
            Button(action: { audioPlayer.play(show: show, episode: episode) }) {
                Image(systemName: isCurrentlyPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.largeTitle)
                    .foregroundColor(isCurrentlyPlaying ? .blue : .primary)
                    .animation(.easeInOut, value: isCurrentlyPlaying)
            }
            .buttonStyle(.plain)
        }
    }
}

//persistent mini-player view that shows at the bottom of the screen.
struct MiniPlayerView: View {
    @EnvironmentObject var audioPlayer: AudioPlayerViewModel

    var body: some View {
        //only show the player if an episode has been selected.
        if let episode = audioPlayer.currentlyPlaying, let show = audioPlayer.currentShow {
            VStack(spacing: 0) {
                //separator line
                Rectangle()
                    .frame(height: 1)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    VStack(alignment: .leading) {
                        Text(episode.title)
                            .font(.headline)
                            .lineLimit(1)
                        Text(show.title)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()

                    PlayButton(show: show, episode: episode)
                }
                .padding()
            }
            .background(.thinMaterial) // translucent background that adapts to light/dark mode
            .transition(.move(edge: .bottom)) //animate appearance from the bottom
        }
    }
}
