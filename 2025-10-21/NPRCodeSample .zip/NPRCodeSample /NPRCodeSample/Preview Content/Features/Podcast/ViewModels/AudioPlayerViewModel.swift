//
//  AudioPlayerViewModel.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/27/25.
//

import AVFoundation
//0: import the media player
import MediaPlayer

@MainActor
class AudioPlayerViewModel: NSObject, ObservableObject {
    
    //MARK: Properties
    private var player: AVPlayer?
    private var timeObserver: Any?
    private var statusObserver: NSKeyValueObservation?
    
    @Published var currentShow: PodcastShow? = nil
    @Published var currentlyPlaying: PodcastEpisode? = nil
    @Published var isPlaying = false
    @Published var isBuffering = false
    @Published var audioError: AudioPlayerError? = nil
    
    //MARK: Lifecycle
    override init() {
        super.init()
        do {
            try setupAudioSession()
        } catch {
            self.audioError = .sessionSetupFailed(error)
        }
        setupRemoteTransportControls()
    }
    
    //MARK: Public Methods
    func play(show: PodcastShow, episode: PodcastEpisode) {
        if currentlyPlaying == episode {
            if isPlaying { player?.pause() } else { player?.play() }
        } else {
            //removes old observers before creating new player
            cleanupPlayer()
            
            //new episode, so start buffering.
            currentlyPlaying = episode
            currentShow = show
            isBuffering = true
            isPlaying = false
            
            let playerItem = AVPlayerItem(url: episode.audioURL)
            self.player = AVPlayer(playerItem: playerItem)
            
            addStatusObserver()
            addPlayerStateObserver()
        }
    }
    
    //MARK: Private helpers
    private func setupAudioSession() throws {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
        try AVAudioSession.sharedInstance().setActive(true)
    }
    
    private func cleanupPlayer() {
        //remove the time observer from the existing player instance.
        if let timeObserver = timeObserver {
            player?.removeTimeObserver(timeObserver)
            self.timeObserver = nil
        }
        //remove the status observer.
        statusObserver?.invalidate()
        self.statusObserver = nil
        //pause the player before deallocating.
        player?.pause()
        self.player = nil
    }
    
    private func addStatusObserver() {
        statusObserver = player?.currentItem?.observe(\.status, options: [.new, .initial]) { [weak self] item, _ in
            
            Task { @MainActor in
                guard let self = self, let episode = self.currentlyPlaying, let show = self.currentShow else {return}
                if item.status == .readyToPlay {
                    self.isBuffering = false
                    self.updateNowPlayingInfo(for: episode, show: show, duration: item.duration.seconds)
                    self.player?.play()
                } else if item.status == .failed {
                    self.isBuffering = false
                    self.audioError = .failedToLoadItem
                }
            }
        }
    }
    
    private func addPlayerStateObserver() {
        //remove any existing observer before adding a new one
        if let timeObserver = timeObserver {
            player?.removeTimeObserver(timeObserver)
        }
        
        //observe the timeControlStatus to get real-time play/pause state
        timeObserver = player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: .main) { [weak self] _ in
            Task { @MainActor in
                guard let self = self, let player = self.player else { return }
                //update the isPlaying property based on the player's status
                let newIsPlaying = (player.timeControlStatus == .playing)
                if newIsPlaying != self.isPlaying {
                    self.isPlaying = newIsPlaying
                    //update the lock screen whenever the play/pause state changes.
                    self.updateNowPlayingPlaybackInfo()
                }
            }
        }
    }
    
    //MARK: Now Playing
    private func setupRemoteTransportControls() {
        let commandCenter = MPRemoteCommandCenter.shared()
        
        commandCenter.playCommand.addTarget { [unowned self] event in
            if !self.isPlaying {
                self.player?.play()
                self.updateNowPlayingPlaybackInfo()
                return .success
            }
            return .commandFailed
        }
        
        commandCenter.pauseCommand.addTarget { [unowned self] event in
            if self.isPlaying {
                self.player?.pause()
                self.updateNowPlayingPlaybackInfo()
                return .success
            }
            return .commandFailed
        }
        
    }
    
    private func updateNowPlayingInfo(for episode: PodcastEpisode, show: PodcastShow, duration: TimeInterval) {
        var nowPlayingInfo = [String: Any]()
        //1 (numbered elements of MPMediaItemProperties)
        nowPlayingInfo[MPMediaItemPropertyTitle] = episode.title
        //2
        nowPlayingInfo[MPMediaItemPropertyPlaybackDuration] = duration
        //3
        let image = UIImage(named: show.iconName) ?? UIImage()
        nowPlayingInfo[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: image.size) { _ in
            return image
        }
        
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nowPlayingInfo
    }
    
    private func updateNowPlayingPlaybackInfo() {
        guard var nowPlayingInfo = MPNowPlayingInfoCenter.default().nowPlayingInfo else { return }
        //fix for lock screen player duration resetting on pause. Failure to provide this restarts the visual elements showing elapsed time of show on lock screen.
        //4
        nowPlayingInfo[MPNowPlayingInfoPropertyElapsedPlaybackTime] = player?.currentItem?.currentTime().seconds
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nowPlayingInfo
        
    }
    
    deinit {
        //clean up the observer when the view model is deallocated
        if let timeObserver = timeObserver {
            player?.removeTimeObserver(timeObserver)
        }
    }
}
