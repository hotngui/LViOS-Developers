//
//  PodcastFeedViewModel.swift
//  NPRCodeSample
//
//  Created by Nicholas Boleky on 7/27/25.
//

import Foundation

@MainActor
class PodcastFeedViewModel: ObservableObject {
    @Published var episodes: [PodcastEpisode] = []
    @Published var isLoading = false
    @Published var errorMessage: FeedError? = nil
    
    private let feedProvider: FeedProvidable
    
    init(feedProvider: FeedProvidable = FeedProvider()) {
        self.feedProvider = feedProvider
    }

    func fetchEpisodes(from url: URL) async {
        isLoading = true
        errorMessage = nil
        
        defer { isLoading = false }
        
        do {
            self.episodes = try await feedProvider.fetchPodcastEpisodes(from: url)
        } catch let error as FeedError {
            self.errorMessage = error
        } catch {
            self.errorMessage = .unknown
        }
    }
}
