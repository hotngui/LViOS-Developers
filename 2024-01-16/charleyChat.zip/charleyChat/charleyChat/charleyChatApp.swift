//
//  charleyChatApp.swift
//  charleyChat
//
//  Created by Charley Ho on 1/15/24.
//

import SwiftUI

@main
struct charleyChatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
