//
//  ContentView.swift
//  JoeyChat
//
//  Created by Charley Ho on 1/16/24.
//

import SwiftUI
import OpenAI

struct ContentView: View {
    @State private var inputText: String = ""
    @State private var displayedText: String = ""
//    @State private var generatedImage: URL?
    @State private var generatedImage: URL? = URL(string: "https://oaidalleapiprodscus.blob.core.windows.net/private/org-ifnJAnrS5D1ZMfG9oNsS4WlR/user-0XySgZAFi6as0Hih4Ve9BYFX/img-lonaJ9eQduB77XAK8r8QVwsM.png?st=2024-01-17T03%3A10%3A26Z&se=2024-01-17T05%3A10%3A26Z&sp=r&sv=2021-08-06&sr=b&rscd=inline&rsct=image/png&skoid=6aaadede-4fb3-4698-a8f6-684d7786b067&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2024-01-16T15%3A46%3A27Z&ske=2024-01-17T15%3A46%3A27Z&sks=b&skv=2021-08-06&sig=m%2BwMOfLtud/8ozkDRyyEm0MadnxfKPg6HE0sSm3Zs5c%3D")

    // TODO: replace key with real OpenAI key
    static private var APIKey = "<ENTER KEY HERE>"
    private let openAIClient = OpenAI(apiToken: Self.APIKey)

    var body: some View {
        VStack {
            // TextField at the top
            TextField("Type something...", 
                      text: $inputText) {
                sendToOpenAI(input: inputText)
            }
                .padding()
                .border(Color.gray, width: 1)

            // Button in the middle
            Button("Submit") {
                // Action when the button is pressed
                sendToOpenAI(input: inputText)
            }
            .padding()

            // Text at the bottom
            ScrollView {
                Text(displayedText)
                    .padding()
            }
            Spacer()
            // Displaying the generated image
            if let image = generatedImage {
                VStack {
                    AsyncImage(url: image) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(maxWidth: 480, maxHeight: 480)
                    } placeholder: {
                        ProgressView()
                    }
                }
            }
        }
    }
    
    func sendToOpenAI(input: String) {
        let query = ChatQuery(model: .gpt4_1106_preview, messages: [
            Chat(role: .system, content: "You are a magical giraffe that can talk, but you only refer to things relative to what you know in the african safari. You only respond in a whimsical mood, frequently accompanied by a song."),
            Chat(role: .user, content: "What is 2x2"),
            Chat(role: .assistant, content: "4, but I'd rather be eating leaves in the jungle. 🎶 Hooray!  🎶"),
            Chat(role: .user, content: input)
        ])
            openAIClient.chats(query: query) { result in
                switch result {
                case .success(let completion):
                    DispatchQueue.main.async {
                        if let content = completion.choices.first?.message.content {
                            self.displayedText = content
                        }
                    }
                case .failure(let error):
                    DispatchQueue.main.async {
                        self.displayedText = "Error: \(error.localizedDescription)"
                    }
                }
            }
            generateImage(input: input)
        }

    func generateImage(input: String) {
        let query = ImagesQuery(prompt: input, n: 1, size: "1024x1024")
        openAIClient.images(query: query) { result in
            switch result {
            case let .success(data):
                if let resultURL = data.data[0].url {
                    print("resultURL", resultURL)
                    self.generatedImage = URL(string: resultURL)
                }
            default:
                return
            }
        }

    }
}

#Preview {
    ContentView()
}
