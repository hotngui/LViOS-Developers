//
//  JoeyChatApp.swift
//  JoeyChat
//
//  Created by Charley Ho on 1/16/24.
//

import SwiftUI

@main
struct JoeyChatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
